<?php
/**
 * Gwangi template hooks for Jetpack.
 *
 * @package gwangi
 */

/**
 * Other hooks.
 *
 * @since 1.0.0
 */
add_filter( 'gwangi_is_mobile', 'jetpack_is_mobile', 10, 1 );
