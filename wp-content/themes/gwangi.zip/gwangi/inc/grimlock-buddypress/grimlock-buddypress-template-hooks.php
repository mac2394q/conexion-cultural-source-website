<?php
/**
 * Gwangi template Hooks for Grimlock for BuddyPress.
 *
 * @package gwangi
 */

add_action( 'grimlock_buddypress_member_swap_loop', 'gwangi_grimlock_buddypress_member_swap_svg', 5 );
